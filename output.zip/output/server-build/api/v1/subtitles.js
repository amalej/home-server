"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const utils_1 = require("../../utils");
const path_1 = __importDefault(require("path"));
const subtitles = (0, express_1.Router)();
subtitles.get("/", (req, res, next) => {
    return res.send("api/v1/subtitles");
});
subtitles.get("/file(*)?", async (req, res, next) => {
    const queries = req.query;
    const parent = queries["parent"] || null;
    const showPath = queries["showPath"] || null;
    try {
        if (typeof showPath !== "string" || typeof parent !== "string") {
            return res.status(400).send(`Missing "showPath" and/or "parent" query`);
        }
        const showPathArray = showPath.split(/\\|\//g);
        showPathArray.pop();
        const showParentPath = showPathArray.join(path_1.default.sep);
        const children = await (0, utils_1.readPathInParentDir)(parent, showParentPath);
        const subtitleFiles = [];
        for (let i = 0; i < children.length; i++) {
            const child = children[i];
            const label = child.split("-").at(-1)?.replace(".vtt", "") || "";
            if (child.endsWith(".vtt")) {
                subtitleFiles.push({
                    label,
                    path: child,
                });
            }
        }
        return res.json({
            files: subtitleFiles,
        });
    }
    catch (error) {
        console.log(error);
    }
});
exports.default = subtitles;
