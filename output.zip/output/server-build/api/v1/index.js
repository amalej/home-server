"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const shows_1 = __importDefault(require("./shows"));
const subtitles_1 = __importDefault(require("./subtitles"));
const v1 = express_1.default.Router();
v1.get("/", function (req, res, next) {
    return res.send("api/v1");
});
v1.use("/shows", shows_1.default);
v1.use("/subtitles", subtitles_1.default);
exports.default = v1;
