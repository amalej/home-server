"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.hostAddress = exports.uploadPath = exports.webClientPath = exports.corsOptions = exports.isProd = exports.serverEnv = void 0;
const path_1 = __importDefault(require("path"));
const utils_1 = require("../utils");
exports.serverEnv = process.env.SERVER_ENVIRONMENT || "development";
exports.isProd = exports.serverEnv === "production";
exports.corsOptions = {
    origin: "*",
    methods: ["POST", "GET", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization", "x-user-id"],
};
exports.webClientPath = exports.isProd
    ? path_1.default.join(__dirname, "..", "..", `${process.env.WEB_CLIENT_BUILD_DIR}`)
    : path_1.default.join(__dirname, "..", "..", "..", "web-client", "build");
exports.uploadPath = exports.isProd
    ? path_1.default.join(__dirname, "..", "..", "uploads/")
    : path_1.default.join(__dirname, "..", "..", "..", "uploads/");
exports.hostAddress = (0, utils_1.findHostAddress)();
