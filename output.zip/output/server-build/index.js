"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const path_1 = __importDefault(require("path"));
const cors_1 = __importDefault(require("cors"));
const fs_1 = __importStar(require("fs"));
const utils_1 = require("./utils");
require("dotenv/config");
const config_1 = require("./config");
const multer_upload_1 = require("./multer-upload");
const promises_1 = require("fs/promises");
const user_data_1 = require("./user-data");
const app = (0, express_1.default)();
app.use(express_1.default.static(config_1.webClientPath));
app.use((0, cors_1.default)(config_1.corsOptions));
// app.use("/", api);
app.get("/api/v1/shows", (0, cors_1.default)(config_1.corsOptions), async (req, res) => {
    const api = "/api/v1/shows";
    (0, utils_1.logToTerminal)(api, "START");
    const userId = req.headers["x-user-id"] || null;
    (0, utils_1.logToTerminal)(api, "userId:", userId);
    try {
        const showsJson = await (0, utils_1.loadShowsPathsJson)();
        if (showsJson === null) {
            res.status(404).send("No 'shows.json' file found.");
        }
        else {
            const files = await (0, utils_1.loadShowsParentDirectories)(showsJson);
            const sorted = files.sort((a, b) => {
                if (a.relativePath < b.relativePath) {
                    return -1;
                }
                if (a.relativePath < b.relativePath) {
                    return 1;
                }
                return 0;
            });
            res.type("json").send(sorted);
        }
    }
    catch (error) {
        console.log(error);
        res.status(500).send("Internal Server error");
    }
});
app.get("/api/v1/shows(/*)?", (0, cors_1.default)(config_1.corsOptions), async (req, res) => {
    const api = "/api/v1/shows(/*)";
    (0, utils_1.logToTerminal)(api, "START");
    const userId = req.headers["x-user-id"] || null;
    (0, utils_1.logToTerminal)(api, "userId:", userId);
    try {
        const mainPath = decodeURIComponent(req.path.replace("/api/v1/shows/", ""));
        const queries = req.query;
        const parent = queries["parent"];
        (0, utils_1.logToTerminal)(api, "mainPath:", mainPath);
        (0, utils_1.logToTerminal)(api, "parent:", parent);
        const files = await (0, utils_1.loadShowsInParentDirectory)(mainPath, parent);
        const sorted = files.sort((a, b) => {
            if (a.relativePath < b.relativePath) {
                return -1;
            }
            if (a.relativePath < b.relativePath) {
                return 1;
            }
            return 0;
        });
        res.type("json").send(sorted);
    }
    catch (error) {
        console.log(error);
        res.status(500).send("Internal Server error");
    }
});
app.get("/api/v1/shows-poster(/*)?", (0, cors_1.default)(config_1.corsOptions), async (req, res) => {
    const api = "/api/v1/poster(/*)?";
    (0, utils_1.logToTerminal)(api, "START");
    const showsJson = await (0, utils_1.loadShowsPathsJson)();
    const queries = req.query;
    const showName = decodeURIComponent(queries["name"]);
    const parent = queries["parent"];
    const showRootDirPath = path_1.default.join(showsJson[parent], showName);
    const posterPath = await (0, utils_1.loadShowPosterPath)(showRootDirPath);
    (0, utils_1.logToTerminal)(api, "showName:", showName);
    (0, utils_1.logToTerminal)(api, "posterPath:", posterPath);
    if (posterPath === null) {
        res.status(404).send("file-not-found");
    }
    else {
        try {
            const imageStream = fs_1.default.createReadStream(posterPath);
            imageStream.pipe(res);
        }
        catch (error) {
            res.status(404).send("file-not-found");
        }
    }
});
app.get("/api/v1/video(/*)?", (0, cors_1.default)(config_1.corsOptions), async (req, res) => {
    const api = "/api/v1/video(/*)?";
    (0, utils_1.logToTerminal)(api, "START");
    // const startDate = new Date();
    const showsJson = await (0, utils_1.loadShowsPathsJson)();
    const range = req.headers.range;
    if (!range) {
        res.status(400).send("Requires Range header");
        return;
    }
    const queries = req.query;
    const parent = queries["parent"];
    const relativePath = queries["relativePath"];
    const videoPath = path_1.default.join(showsJson[parent], relativePath);
    const userId = queries["uid"] || null;
    try {
        const video = (0, fs_1.statSync)(videoPath);
        const videoSize = video.size;
        const CHUNK_SIZE = 1000000;
        const start = Number(range.replace(/\D/g, ""));
        const end = Math.min(start + CHUNK_SIZE, videoSize - 1);
        const contentLength = end - start + 1;
        const percentLoaded = (end / videoSize).toFixed(2);
        const headers = {
            "Content-Range": `bytes ${start}-${end}/${videoSize}`,
            "Accept-Ranges": "bytes",
            "Content-Length": contentLength,
            "Content-Type": "video/mp4",
        };
        // const endDate = new Date();
        // logToTerminal(api, "userId:", userId);
        // logToTerminal(api, "videoPath:", videoPath);
        // logToTerminal(api, "startDate", startDate);
        // logToTerminal(api, "endDate:", endDate);
        // logToTerminal(api, "range:", range);
        // logToTerminal(api, "chunks:", `${start}`, " => ", `${end}`);
        // logToTerminal(api, "chunkSize:", `${contentLength}`);
        // logToTerminal(api, "percentage:", `${percentLoaded}`);
        // logToTerminal(
        //   api,
        //   "duration:",
        //   `${endDate.getTime() - startDate.getTime()}`
        // );
        if (typeof userId === "string") {
            (0, user_data_1.setUserWatchingShowData)(userId, relativePath, parseFloat(percentLoaded));
        }
        res.writeHead(206, headers);
        const videoStream = fs_1.default.createReadStream(videoPath, { start, end });
        videoStream.pipe(res);
    }
    catch (error) {
        res.status(404).send("file-not-found");
    }
});
app.get("/api/v1/subtitles", (0, cors_1.default)(config_1.corsOptions), async (req, res) => {
    const queries = req.query;
    const parent = queries["parent"];
    const relativePath = queries["relativePath"];
    const showsJson = await (0, utils_1.loadShowsPathsJson)();
    try {
        const relativePathSplit = relativePath.split("/");
        relativePathSplit.pop();
        const parentPath = path_1.default.join(showsJson[parent], ...relativePathSplit);
        const files = await (0, promises_1.readdir)(parentPath);
        const subtitleFiles = [];
        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            if (file.includes(".vtt")) {
                subtitleFiles.push(path_1.default.join(...relativePathSplit, file));
            }
        }
        res.send(subtitleFiles);
    }
    catch (error) {
        console.log(error);
    }
});
app.get("/api/v1/subtitle-file(/*)?", (0, cors_1.default)(config_1.corsOptions), async (req, res) => {
    const queries = req.query;
    const parent = queries["parent"];
    const relativePath = queries["relativePath"];
    const showsJson = await (0, utils_1.loadShowsPathsJson)();
    const subtitlePath = path_1.default.join(showsJson[parent], relativePath);
    try {
        res.sendFile(subtitlePath);
    }
    catch (error) {
        console.log(error);
    }
});
app.post("/api/v1/upload", (0, cors_1.default)(config_1.corsOptions), multer_upload_1.multerUpload.single("file"), (req, res) => {
    const api = "/api/v1/upload";
    (0, utils_1.logToTerminal)(api, "START");
    res.json({ message: "File uploaded successfully!" });
});
app.get("/api/v1/user-data", (0, cors_1.default)(config_1.corsOptions), (req, res) => {
    const api = "/api/v1/user-data";
    (0, utils_1.logToTerminal)(api, "START");
    const userDataMap = (0, user_data_1.getUserDataMap)();
    res.type("json").send(userDataMap);
});
app.delete("/api/v1/user-data", (0, cors_1.default)(config_1.corsOptions), (req, res) => {
    const api = "/api/v1/user-data";
    (0, utils_1.logToTerminal)(api, "START");
    const queries = req.query;
    const userId = queries["uid"] || null;
    if (typeof userId === "string") {
        (0, user_data_1.deleteUserData)(userId);
    }
    res.send("user-data-deleted");
});
app.get("*", (0, cors_1.default)(config_1.corsOptions), (req, res) => {
    const api = "*";
    (0, utils_1.logToTerminal)(api, "START");
    res.sendFile(path_1.default.join(config_1.webClientPath, "index.html"));
});
app.listen(5000, () => {
    console.log("server env:", config_1.serverEnv);
    console.log(`server started on ${config_1.hostAddress}:5000`);
});
