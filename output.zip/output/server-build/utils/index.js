"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.readPathInParentDir = exports.traverseThenRead = exports.logToTerminal = exports.loadShowPosterPath = exports.findHostAddress = exports.loadShowsInParentDirectory = exports.loadShowsParentDirectories = exports.loadShowsPathsJson = void 0;
const promises_1 = require("fs/promises");
const path_1 = __importDefault(require("path"));
const os_1 = require("os");
async function loadShowsPathsJson() {
    try {
        const removeLastPath = (_path) => {
            const pathArr = _path.split(path_1.default.sep);
            pathArr.pop();
            return pathArr.join(path_1.default.sep);
        };
        let currentPath = __dirname;
        let totalPathSegment = currentPath.split(path_1.default.sep).length;
        let showPath = path_1.default.join(currentPath, "shows-paths.json");
        // Traverse up the directory till a "shows-paths.json" file is found.
        for (let i = 0; i < totalPathSegment; i++) {
            const fileExists = async (path) => !!(await (0, promises_1.stat)(path).catch((e) => false));
            if (!(await fileExists(showPath))) {
                showPath = path_1.default.join(currentPath, "shows-paths.json");
                currentPath = removeLastPath(currentPath);
            }
            else {
                const content = await (0, promises_1.readFile)(showPath, { encoding: "utf-8" });
                return JSON.parse(content);
            }
        }
    }
    catch (error) {
        console.log(error);
    }
    return null;
}
exports.loadShowsPathsJson = loadShowsPathsJson;
async function loadShowsParentDirectories(showsJson) {
    const pathArr = [];
    const directoryNames = Object.keys(showsJson);
    for (let i = 0; i < directoryNames.length; i++) {
        const parent = directoryNames[i];
        const parentPath = showsJson[parent];
        try {
            const filesInDir = await (0, promises_1.readdir)(parentPath);
            for (let j = 0; j < filesInDir.length; j++) {
                const _file = filesInDir[j];
                pathArr.push({
                    relativePath: _file,
                    parent: parent,
                });
            }
        }
        catch (error) {
            // TODO: try and return some error.
            if (error.code === "ENOENT") {
                console.log(error.message);
            }
            else {
                console.log(error);
            }
        }
    }
    return pathArr;
}
exports.loadShowsParentDirectories = loadShowsParentDirectories;
async function loadShowsInParentDirectory(showPath, parent) {
    const showsJson = await loadShowsPathsJson();
    const fileArr = [];
    try {
        const files = await (0, promises_1.readdir)(path_1.default.join(showsJson[parent], showPath));
        for (let i = 0; i < files.length; i++) {
            if (files[i].includes(".txt") ||
                files[i].includes(".log") ||
                files[i].includes(".jpg") ||
                files[i].includes(".png") ||
                files[i].includes(".jpeg") ||
                files[i].includes(".vtt") ||
                files[i].includes(".srt")) {
            }
            else {
                fileArr.push({
                    relativePath: path_1.default.join(showPath, files[i]),
                    parent: parent,
                });
            }
        }
    }
    catch (error) {
        console.log(error);
    }
    return fileArr;
}
exports.loadShowsInParentDirectory = loadShowsInParentDirectory;
function findHostAddress() {
    const nets = (0, os_1.networkInterfaces)();
    const results = Object.create(null);
    for (const name of Object.keys(nets)) {
        const netName = nets[name];
        if (netName !== undefined) {
            for (const net of netName) {
                const familyV4Value = typeof net.family === "string" ? "IPv4" : 4;
                if (net.family === familyV4Value && !net.internal) {
                    if (!results[name]) {
                        results[name] = [];
                    }
                    results[name].push(net.address);
                }
            }
        }
    }
    const keys = Object.keys(results);
    return results[keys[0]];
}
exports.findHostAddress = findHostAddress;
async function loadShowPosterPath(showRootDirPath) {
    try {
        const files = await (0, promises_1.readdir)(showRootDirPath);
        for (let file of files) {
            if (file.includes("poster.")) {
                return path_1.default.join(showRootDirPath, file);
            }
        }
    }
    catch (error) {
        console.log(error);
    }
    return null;
}
exports.loadShowPosterPath = loadShowPosterPath;
function logToTerminal(tag, ...msg) {
    const currentDate = new Date();
    console.log(`\x1b[32m[ \x1b[0m${tag}\x1b[32m ]\x1b[0m`, `\x1b[32m[ \x1b[0m${currentDate.toLocaleString()}\x1b[32m ]\x1b[0m`, ...msg);
}
exports.logToTerminal = logToTerminal;
/**
 * Traverse up a directoru till the file is found.
 * @param fileName Name of the file to find.
 * @returns
 */
async function traverseThenRead(fileName) {
    try {
        const removeLastPath = (_path) => {
            const pathArr = _path.split(path_1.default.sep);
            pathArr.pop();
            return pathArr.join(path_1.default.sep);
        };
        let currentPath = __dirname;
        let totalPathSegment = currentPath.split(path_1.default.sep).length;
        let showPath = path_1.default.join(currentPath, fileName);
        for (let i = 0; i < totalPathSegment; i++) {
            const fileExists = async (path) => !!(await (0, promises_1.stat)(path).catch((e) => false));
            if (!(await fileExists(showPath))) {
                showPath = path_1.default.join(currentPath, fileName);
                currentPath = removeLastPath(currentPath);
            }
            else {
                const content = await (0, promises_1.readFile)(showPath, { encoding: "utf-8" });
                return content;
            }
        }
    }
    catch (error) {
        console.log(error);
    }
    return null;
}
exports.traverseThenRead = traverseThenRead;
async function readPathInParentDir(parentDir, relativePath) {
    return new Promise(async (resolve, reject) => {
        setTimeout(() => {
            return reject("timeout");
        }, 5000);
        try {
            const fileContent = await traverseThenRead("shows-paths.json");
            if (fileContent === null) {
                return reject(`Could find "shows-paths.json`);
            }
            const showsPathsJson = JSON.parse(fileContent);
            const parentPath = showsPathsJson[parentDir];
            if (typeof parentPath !== "string") {
                return reject(`Path for "${parentDir}" does not exist in "shows-paths.json`);
            }
            const fullPath = path_1.default.join(parentPath, relativePath);
            const files = await (0, promises_1.readdir)(fullPath);
            return resolve(files);
        }
        catch (error) {
            return reject(error);
        }
    });
}
exports.readPathInParentDir = readPathInParentDir;
