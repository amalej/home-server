"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteUserData = exports.getUserDataMap = exports.setUserWatchingShowData = void 0;
let userDataMap = {};
function setUserWatchingShowData(userId, show, percentLoaded) {
    const currentDate = new Date();
    if (userDataMap[userId]) {
        userDataMap[userId] = {
            ...userDataMap[userId],
            show: {
                lastWatched: show,
                lastDateWatched: currentDate,
                percentLoaded,
            },
        };
    }
    else {
        userDataMap[userId] = {
            show: {
                lastWatched: show,
                lastDateWatched: currentDate,
                percentLoaded,
            },
        };
    }
}
exports.setUserWatchingShowData = setUserWatchingShowData;
function getUserDataMap() {
    return userDataMap;
}
exports.getUserDataMap = getUserDataMap;
function deleteUserData(userId) {
    delete userDataMap[userId];
}
exports.deleteUserData = deleteUserData;
